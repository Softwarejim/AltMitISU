#ifndef OSAPI_COND_HELPER_HPP
#define OSAPI_COND_HELPER_HPP

namespace osapi
{
  
  struct xxxAwoken
  {
    enum Awoken {
      SIGNALED,
      TIMEDOUT
    };    
  };

}



#endif
